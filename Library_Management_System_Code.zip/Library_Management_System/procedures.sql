DELIMITER
 $$

CREATE PROCEDURE
 
sp_issue_book
(
    
IN
  p_usn          
VARCHAR
(
12
),
    
IN
  p_book_id      
INT
,
    
IN
  p_librarian_id 
INT
,
    
OUT
 p_issue_id     
INT

)

BEGIN

    
-- Insert into issue_record; trigger auto-sets due_date and decrements copies

    
INSERT INTO
 issue_record (usn, book_id, librarian_id, issue_date, due_date)
    
VALUES
 (p_usn, p_book_id, p_librarian_id, 
CURRENT_DATE
,
            
DATE_ADD
(
CURRENT_DATE
, 
INTERVAL
 
15
 
DAY
));

    
SET
 p_issue_id = 
LAST_INSERT_ID
();

END
$$

DELIMITER
 ;

DELIMITER
 $$


-- Mark a book as returned (trigger fires to handle fine + copy restore)


CREATE PROCEDURE
 
sp_return_book
(
IN
 p_issue_id 
INT
)

BEGIN

    
UPDATE
 issue_record
    
SET
    return_date = 
CURRENT_DATE

    
WHERE
  issue_id = p_issue_id;

END
$$


-- Returns all issues that need a reminder email (due in ≤2 days, not yet reminded)


CREATE PROCEDURE
 
sp_get_pending_reminders
()

BEGIN

    
SELECT
 ir.issue_id, ir.usn,
           s.name  
AS
 student_name,
           s.email 
AS
 student_email,
           b.title 
AS
 book_title,
           ir.due_date,
           
DATEDIFF
(ir.due_date, 
CURRENT_DATE
) 
AS
 days_remaining
    
FROM
  issue_record ir
    
JOIN
  student s 
ON
 ir.usn     = s.usn
    
JOIN
  book    b 
ON
 ir.book_id = b.book_id
    
WHERE
 ir.status        = 
'ISSUED'

      
AND
 ir.reminder_sent = 
0

      
AND
 
CURRENT_DATE
   >= 
DATE_SUB
(ir.due_date, 
INTERVAL
 
2
 
DAY
);

END
$$


-- Called after email is sent so we don't email the same student again


CREATE PROCEDURE
 
sp_mark_reminder_sent
(
IN
 p_issue_id 
INT
)

BEGIN

    
UPDATE
 issue_record
    
SET
    reminder_sent = 
1

    
WHERE
  issue_id = p_issue_id;

END
$$


-- Run daily: marks all unreturned past-due-date books as OVERDUE


CREATE PROCEDURE
 
sp_update_overdue_status
()

BEGIN

    
UPDATE
 issue_record
    
SET
    status = 
'OVERDUE'

    
WHERE
  status      = 
'ISSUED'

      
AND
  return_date 
IS NULL

      
AND
  
CURRENT_DATE
 > due_date;

END
$$


DELIMITER
 ;