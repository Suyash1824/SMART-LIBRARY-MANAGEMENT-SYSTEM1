DELIMITER
 $$


CREATE TRIGGER
 
trg_before_issue


BEFORE INSERT ON
 issue_record

FOR EACH ROW


BEGIN

    
-- Step 1: Check if book has available copies

    
DECLARE
 avail 
INT
;
    
SELECT
 available_copies 
INTO
 avail
    
FROM
   book 
WHERE
 book_id = 
NEW
.book_id;

    
IF
 avail < 
1
 
THEN

        
SIGNAL SQLSTATE
 
'45000'

            
SET
 MESSAGE_TEXT = 
'No copies available for this book.'
;
    
END IF
;

    
-- Step 2: Auto-set due date = issue date + 15 days

    
SET
 
NEW
.due_date = 
DATE_ADD
(
NEW
.issue_date, 
INTERVAL
 
15
 
DAY
);

END
$$


DELIMITER
 ;

DELIMITER
 $$


CREATE TRIGGER
 
trg_after_issue


AFTER INSERT ON
 issue_record

FOR EACH ROW


BEGIN

    
-- Reduce available copies by 1 when a book is issued

    
UPDATE
 book
    
SET
    available_copies = available_copies - 
1

    
WHERE
  book_id = 
NEW
.book_id;

END
$$


DELIMITER
 ;

DELIMITER
 $$


CREATE TRIGGER
 
trg_on_return


BEFORE UPDATE ON
 issue_record

FOR EACH ROW


BEGIN

    
DECLARE
 overdue_days 
INT
;
    
DECLARE
 fine_amt     
DECIMAL
(
10
,
2
);

    
-- Only runs when return_date changes from NULL to an actual date

    
IF OLD
.return_date 
IS NULL AND NEW
.return_date 
IS NOT NULL THEN


        
-- Put the copy back

        
UPDATE
 book
        
SET
    available_copies = available_copies + 
1

        
WHERE
  book_id = 
NEW
.book_id;

        
SET NEW
.status = 
'RETURNED'
;

        
-- Calculate how many days late (0 if on time)

        
SET
 overdue_days = 
GREATEST
(
0
, 
DATEDIFF
(
NEW
.return_date, 
NEW
.due_date));
        
SET
 fine_amt     = overdue_days * 
5.00
;  
-- ₹5 per overdue day


        
-- Insert fine record only if book is late

        
IF
 overdue_days > 
0
 
THEN

            
INSERT INTO
 fine (issue_id, days_overdue, fine_amount)
            
VALUES
 (
NEW
.issue_id, overdue_days, fine_amt);
        
END IF
;

    
END IF
;

END
$$


DELIMITER
 ;