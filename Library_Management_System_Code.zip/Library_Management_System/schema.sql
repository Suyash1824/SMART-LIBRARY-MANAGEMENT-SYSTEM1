-- ============================================================
-- LIBRARY MANAGEMENT SYSTEM - DATABASE SCHEMA
-- Run this file in MySQL Workbench to set up everything
-- ============================================================



CREATE DATABASE IF NOT EXISTS
 library_mgmt;

USE
 library_mgmt;


-- ─── TABLE 1: STUDENT ───────────────────────────────────────


CREATE TABLE IF NOT EXISTS
 student (
    usn         
VARCHAR
(
12
)   
PRIMARY KEY
,       
-- e.g. 4SF24CI001

    name        
VARCHAR
(
100
)  
NOT NULL
,
    email       
VARCHAR
(
100
)  
NOT NULL UNIQUE
,  
-- college email for reminders

    phone       
VARCHAR
(
15
),
    department  
VARCHAR
(
50
)   
NOT NULL
,
    semester    
INT
           
NOT NULL

);


-- ─── TABLE 2: BOOK ──────────────────────────────────────────


CREATE TABLE IF NOT EXISTS
 book (
    book_id          
INT
          
AUTO_INCREMENT PRIMARY KEY
,
    title            
VARCHAR
(
200
) 
NOT NULL
,
    author           
VARCHAR
(
100
) 
NOT NULL
,
    subject          
VARCHAR
(
50
),   
-- OS, DAA, DBMS, AI, etc.

    total_copies     
INT
          
NOT NULL DEFAULT
 
1
,
    available_copies 
INT
          
NOT NULL DEFAULT
 
1

);


-- ─── TABLE 3: LIBRARIAN ─────────────────────────────────────


CREATE TABLE IF NOT EXISTS
 librarian (
    librarian_id  
INT
          
AUTO_INCREMENT PRIMARY KEY
,
    name          
VARCHAR
(
100
) 
NOT NULL
,
    email         
VARCHAR
(
100
) 
NOT NULL UNIQUE
,
    password_hash 
VARCHAR
(
255
) 
NOT NULL

);


-- ─── TABLE 4: ISSUE_RECORD ──────────────────────────────────


CREATE TABLE IF NOT EXISTS
 issue_record (
    issue_id      
INT
         
AUTO_INCREMENT PRIMARY KEY
,
    usn           
VARCHAR
(
12
) 
NOT NULL
,
    book_id       
INT
         
NOT NULL
,
    librarian_id  
INT
         
NOT NULL
,
    issue_date    
DATE
        
NOT NULL DEFAULT
 (
CURRENT_DATE
),
    due_date      
DATE
        
NOT NULL
,     
-- auto-set by trigger = issue_date + 15

    return_date   
DATE
        
DEFAULT NULL
, 
-- NULL means not yet returned

    status        
ENUM
(
'ISSUED'
, 
'RETURNED'
, 
'OVERDUE'
) 
DEFAULT
 
'ISSUED'
,
    reminder_sent 
TINYINT
(
1
)  
DEFAULT
 
0
,   
-- set to 1 after email is sent

    
FOREIGN KEY
 (usn)         
REFERENCES
 student(usn),
    
FOREIGN KEY
 (book_id)     
REFERENCES
 book(book_id),
    
FOREIGN KEY
 (librarian_id)
REFERENCES
 librarian(librarian_id)
);


-- ─── TABLE 5: FINE ──────────────────────────────────────────


CREATE TABLE IF NOT EXISTS
 fine (
    fine_id        
INT
             
AUTO_INCREMENT PRIMARY KEY
,
    issue_id       
INT
             
NOT NULL UNIQUE
, 
-- one fine per issue

    days_overdue   
INT
             
NOT NULL DEFAULT
 
0
,
    fine_amount    
DECIMAL
(
10
,
2
)  
NOT NULL DEFAULT
 
0.00
,
    payment_status 
ENUM
(
'PENDING'
,
'PAID'
) 
DEFAULT
 
'PENDING'
,
    calculated_on  
DATE
            
NOT NULL DEFAULT
 (
CURRENT_DATE
),
    
FOREIGN KEY
 (issue_id) 
REFERENCES
 issue_record(issue_id)
);


-- ─── SAMPLE DATA ────────────────────────────────────────────


INSERT INTO
 librarian (name, email, password_hash) 
VALUES

(
'Admin Librarian'
, 
'librarian@college.edu'
, 
SHA2
(
'admin123'
, 
256
));


INSERT INTO
 student (usn, name, email, phone, department, semester) 
VALUES

(
'4SF24CI001'
, 
'Arjun Sharma'
,   
'arjun.sharma@college.edu'
,   
'9876543210'
, 
'CSE (AI&ML)'
, 
2
),
(
'4SF24CI002'
, 
'Priya Nair'
,     
'priya.nair@college.edu'
,     
'9876543211'
, 
'CSE (AI&ML)'
, 
2
),
(
'4SF24CS001'
, 
'Rohan Mehta'
,    
'rohan.mehta@college.edu'
,    
'9876543212'
, 
'CSE'
,         
4
),
(
'4SF24IS001'
, 
'Sneha Kulkarni'
, 
'sneha.kulkarni@college.edu'
, 
'9876543213'
, 
'ISE'
,         
4
),
(
'4SF24EC001'
, 
'Kiran Reddy'
,    
'kiran.reddy@college.edu'
,    
'9876543214'
, 
'ECE'
,         
6
);


INSERT INTO
 book (title, author, subject, total_copies, available_copies) 
VALUES


-- Operating Systems

(
'Operating System Concepts'
,       
'Silberschatz, Galvin'
,   
'OS'
,   
4
, 
4
),
(
'Modern Operating Systems'
,         
'Andrew Tanenbaum'
,       
'OS'
,   
3
, 
3
),

-- Design & Analysis of Algorithms

(
'Introduction to Algorithms (CLRS)'
, 
'Cormen, Leiserson'
,     
'DAA'
,  
3
, 
3
),
(
'Algorithm Design'
,                 
'Kleinberg & Tardos'
,     
'DAA'
,  
2
, 
2
),

-- DBMS

(
'Database System Concepts'
,         
'Silberschatz'
,           
'DBMS'
, 
4
, 
4
),
(
'Database Management Systems'
,      
'Ramakrishnan & Gehrke'
, 
'DBMS'
, 
3
, 
3
),

-- Artificial Intelligence

(
'Artificial Intelligence: A Modern Approach'
, 
'Russell & Norvig'
, 
'AI'
, 
3
, 
3
),
(
'Deep Learning'
,                    
'Goodfellow, Bengio'
,    
'AI'
,   
2
, 
2
);
